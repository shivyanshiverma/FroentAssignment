import React,{ useEffect, useState } from 'react'
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { makeStyles } from "@mui/styles";
import { styled } from "@mui/material";

const CssTextField=styled(TextField)({
    "& .MuiInput-underline:before":{
      borderBottomColor:"rgba(255, 255, 255, 0.50)"
    },
    "& .MuiInput-underline:after":{
      borderBottomColor:"rgba(255, 255, 255, 0.50)"
    },
    "& .MuiInputLabel-root": {
      color: "rgba(255, 255, 255, 0.50)", 
    },
    "& .MuiInputBase-input": {
      color: "rgba(255, 255, 255, 0.50)", 
    },
  })
  
  
const Home = () => {
    
    const isValidEmail = (email) => {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
      };
      const [errors, setErrors] = useState({});
      const [formData, setFormData] = useState({
        name: '',
        email: '',
        message: '',
      });
      const handleSubmit = (e) => {
        e.preventDefault();
        // Validate the form data
        const validationErrors = validateForm(formData);
        if (Object.keys(validationErrors).length === 0) {
          // If no validation errors, submit the form (you can make an API call here)
          console.log('Form submitted:', formData);
        } else {
          // If there are validation errors, update the errors state
          setErrors(validationErrors);
        }
      };
      const validateForm = (data) => {
        const errors = {};
        // Add validation rules here
        if (!data.name.trim()) {
          errors.name = 'Name is required';
        }
        if (!data.email.trim()) {
          errors.email = 'Email is required';
        } else if (!isValidEmail(data.email)) {
          errors.email = 'Invalid email address';
        }
        if (!data.message.trim()) {
          errors.message = 'Message is required';
        }
        return errors;
      };
      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
          ...formData,
          [name]: value,
        });
      };
    const navbar = [
        { name: 'Home', id: 'home' },
        { name: 'About', id: 'about' },
        {
          name: 'Our Products',
          id: 'product',
          child: [
            { name: 'Product 1', id: 'p1' },
            { name: 'Product 2', id: 'p2' },
            { name: 'Product 3', id: 'p3' },
            { name: 'Product 4', id: 'p4' },
          ],
        },
        { name: 'Contact Us', id: 'contact' },
      ];



    //   dynamic navbar
      const generateMenuItems = (items) => {
        return items.map((item) => {
          if (item.child) {
           
            return (
              <li key={item.id}>
                <a href={`#${item.id}`}>{item.name}</a>
                <ul className="dropdown">
                  {generateMenuItems(item.child)}
                </ul>
              </li>
            );
          } else {
            
            return (
              <li key={item.id}>
                <a href={`#${item.id}`}>{item.name}</a>
              </li>
            );
          }
        });
      };

    //   api integration
      const [products, setProducts] = useState([]);
      useEffect(() => {
      
        fetch('https://fakestoreapi.com/products')
          .then((response) => response.json())
          .then((data) => {
           
            setProducts(data);
          })
          .catch((error) => console.error('Error fetching data:', error));
      }, []); 
      
      console.log(products);



    const myFunction = () => {
        document.getElementById("myDropdown").classList.toggle("show");
      };
     


  return (
    <>
    <div className="main">
      {/* header */}
      <div className="header">
        <div className="leftheader">
          <h5>Free Delivery</h5>
          <p>|</p>
          <h5>Return Policy</h5>
        </div>
        <div className="rightheader">
          <h5 className="login">Login</h5>
          <h5>Follow Us</h5>
          <i class="ri-facebook-line"></i>
          <i class="ri-linkedin-line"></i>
          <i class="ri-twitter-line"></i>
          <i class="ri-instagram-line"></i>
        </div>
      </div>
      {/* ShopKart */}
      <div className="shopKart">
        <div className="leftShopKart">
          <h3>ShopKart</h3>
        </div>
        <div className="rightShopKart">
          <h4>WISHLIST(0)</h4>
          <h4>BAG(0)</h4>
        </div>
      </div>
      {/* menus */}

      <div className="menu">
        
        <ul>
        {generateMenuItems(navbar)}
      </ul>
      </div>
      <div className="midSection">
        <div className="midSectionLeft">
          <h3 className="fresh">Fresh</h3>
          <h3 className="twenty">2022</h3>
          <h3 className="look">Look</h3>
        </div>
        <div className="midSectionRight"></div>
        <div className="image"></div>
      </div>
    </div>
    {/* card section */}
    <section className="middleSection">
      <div className="leftSection">
        <div className="leftSectionTop">
          <h2>New products</h2>
        </div>
        <div className="leftSectionbottom">
          <h6>Apparel</h6>
          <h6 className="accessories">Accessories</h6>
          <h6>Best Seller</h6>
          <h6>50% off</h6>
        </div>
      </div>
      <div className="rightSection">
         <div className="card">
          <img src="https://s3-alpha-sig.figma.com/img/18dd/a13e/07d18c9e3059f7e9658764387e84c47e?Expires=1698019200&Signature=MDePyefvB2xzcE6RJ0iePVxGIhlEPWWps~sOQ9xtNlsKuL~P~gbvHunM3hn1musw3EyV-ncXkKJaDc8Un5www0c6xAMDt9XpYTFSh49ZO1oynyFqdZmC2wdf6esQi9I~fWFmk90FAZ6UspMv7FyfuW4pXPaeH-rGqBVa116LjAYHBF2yKJPd6u0VD0lv1cwxD7LUwyZQxa-Jq7VXGk1sW2vEIXo-Z586A2wzGFebbOhO74wIMTfGhXpB69~Lu3Ln3WDxVdVXw62pvG5i-WnUznPp8SyaSnw3H613ZK~dxDnVaWP7NZWF-2r2VFt9OaoOV8K3tUuhrxWNhxorpV6Grw__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4" />
          <h2 className="cardtext">FLORIDA JACKET</h2>
          <span className="cardtext">
            img elements must have an alt prop, either with meaningful text,
            or an empty string for decorative images
          </span>
          <h2 className="cardtext">$1OO</h2>
        </div> 
         

         <div className="card">
          <img src="https://s3-alpha-sig.figma.com/img/c720/4cb2/04eb2b299e5bbdcf1dc998f1a18fc075?Expires=1698019200&Signature=e2q4kml~dcX59q~HKyI0y-4olnd7-x9W-y2yS3LFzT4XcsSNCT~Kc6CQhvQmLB6slt1oKRIbPDklUoCBJyxRZNUX-xArQPDXp60VmAqYORVI54~h-68omhmSJ~~f-Qqh4570H5oxBykrvMkPFVI~BSg0Z2z4IhPenku5NgOJdxpd-3~3uYypgwai8GDXWxEVV~-Xyx4Rn0tJqjSQEt0BAY1pEyJta0DV78N7aDIrd~suqvXHnqKGm5-Uja2LeQRq6cdTHde6VpCeqYUhULxuKwKgV23qfr3nEgxx4Ou9roVw4BzEai7M-F473M9SGSBi6-tui-g~9vuoLbsE1ZOm1Q__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4" />
          <h2 className="cardtext">FLORIDA JACKET</h2>
          <span className="cardtext">
            img elements must have an alt prop, either with meaningful text,
            or an empty string for decorative images
          </span>
          <h2 className="cardtext">$1OO</h2>
        </div> 

         <div className="card">
          <img src="https://s3-alpha-sig.figma.com/img/4329/e31e/84b3cd2018cf371c37de3221507d40d3?Expires=1698019200&Signature=JBIgk0XKul7Rq1P39904Oj5iTx0foHxeMVy8uwt~HBNsXxUIaNIIZjmq-ZjfbqAY-f3ml5TSnFS5jNs~F6L82Hrwg9-aQtZtjW99TUPLGHAecKXRLn1RT6A2F8QR8pXlMu-zetv-iRsM2pXIO-LYGjwjT8PsimWSAAPFZjn7H9YtD5SJe09uWgxLTrzcWw1UjNJoZA63z0tcizEIiqqg7kHipwSUmEm4jKzUnKfyGEmk6r~IF~AbYTM6oiOdd5SFNC3HBpLLzBYc7x~m0aHAbL9jOR7t716xmmFHjNaq~Gp9iNjmhvx5ZLpwKPP~dvMExLoTVnveaRn2xe7DpAG4uw__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4" />
          <h2 className="cardtext">FLORIDA JACKET</h2>
          <span className="cardtext">
            img elements must have an alt prop, either with meaningful text,
            or an empty string for decorative images
          </span>
          <h2 className="cardtext">$1OO</h2>
        </div> 

         <div className="card">
          <img src="https://s3-alpha-sig.figma.com/img/6638/2a28/fa0e6c311e6612856bf388ff560713f4?Expires=1698019200&Signature=pvrbDNqkbI~nNfF3R7aqn5J6Mnm6bK~oaH6UYt6r8Kg4t~mHr5D0PMG-6fVyCKo5gxST0Kk6WvcTDD~KcYxiQHxcL~geL87hf9K~WL86PC7fLWJrikUVcXjWJSJ1DhLHouH-90HSiSw5hKoiHHkXP5Gru6CaPMBZZJweipzm5s9oeLhILp~mW-AgTwf9Q0u8eNCNxzGrLABHsoEXPbEQFxilVyXckK9dQH93X6tUbL3GWcAPgE01EfDdERFtoJlGQfWGZ~bM-EtQk6VAuZ~G13mXbBC73isvvKn9CgIiX6Sb2ziXrl3KZXOnhg~uFsXd86IOLWysi3AmSdFCi8lueA__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4" />
          <h2 className="cardtext">FLORIDA JACKET</h2>
          <span className="cardtext">
            img elements must have an alt prop, either with meaningful text,
            or an empty string for decorative images
          </span>
          <h2 className="cardtext">$1OO</h2>
        </div> 
      </div>
    </section>

    {/* last section */}
    <div className="lastSection">
      <div className="lastSectionLeft">
        <h3>Newslleter</h3>
        <p>Get News about articles and updates in your inbox</p>
      </div>
      <div className="lastSectionRight">
        <div className="form" >
          <CssTextField
            id="name"
            label="NAME"
            type="text"
            variant="standard"
            name='name'
            fullWidth
            value={formData.name}
            onChange={handleInputChange}
          
          />
          
          <CssTextField
            id="email"
            label="EMAIL"
            type="email"
            variant="standard"
            fullWidth
            margin="normal"
            name='email'
            value={formData.email}
            onChange={handleInputChange}
          />

          <CssTextField
            id="message"
            label="MESSAGE"
            type="text"
            variant="standard"
            name='message'
            fullWidth
            onChange={handleInputChange}
            value={formData.message}
          />
        {errors.message && <span className="error">{errors.message}</span>}

        </div>
        <button  className='submit' onClick={handleSubmit}>Send</button>
        {/* <Button variant="text" onClick={handleSubmit}>Text</Button> */}

      </div>

      <div className="getinTouch">
          <h1>GET</h1>
          <h1>IN TOUCH</h1>
      </div>

    </div>

    {/* footer */}

    <div className="footer">
        <h5>CopyRight 2022 All Right Reserved By SG</h5>
    </div>
    </>
  )
}

export default Home
