//import logo from './logo.svg';
import './App.css';

import { BrowserRouter } from 'react-router-dom'

import "../node_modules/bootstrap/dist/css/bootstrap.min.css";

import "../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";
import Home from './Pages/Home';
//import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <div >
     
      <Home/>
      
     
    </div>
  );
}

export default App;
